<?php
/**
 * Single Exam page — premium accordion-based exam detail layout
 *
 * @package TenTracker
 */
get_header();

the_post();
$exam_id = get_the_ID();

$quiz_category = (string) get_post_meta( $exam_id, 'exam_quiz_category', true );
$about_html    = (string) get_post_meta( $exam_id, 'exam_about', true );
$ca_html       = (string) get_post_meta( $exam_id, 'exam_current_affairs', true );
$syllabus_html = (string) get_post_meta( $exam_id, 'exam_syllabus', true );
$extra_raw     = (string) get_post_meta( $exam_id, 'exam_accordion_extra', true );
$extra_items   = json_decode( $extra_raw, true );
if ( ! is_array( $extra_items ) ) {
    $extra_items = array();
}
?>

<!-- Hero -->
<header class="tt-exam-hero">
  <div class="tt-container tt-exam-hero__inner">
    <?php tt_breadcrumbs(); ?>

    <div class="tt-exam-hero__grid">
      <div class="tt-exam-hero__content">
        <h1 class="tt-exam-hero__title"><?php the_title(); ?></h1>

        <?php if ( has_excerpt() ) : ?>
          <p class="tt-exam-hero__sub"><?php the_excerpt(); ?></p>
        <?php endif; ?>

        <div class="tt-exam-hero__meta">
          <?php if ( $quiz_category ) : ?>
            <span class="tt-pill tt-pill--blue"><?php echo esc_html( $quiz_category ); ?></span>
          <?php endif; ?>
          <span class="tt-pill tt-pill--muted"><?php esc_html_e( 'Mobile friendly', 'tentracker' ); ?></span>
          <span class="tt-pill tt-pill--muted"><?php esc_html_e( 'Instant results', 'tentracker' ); ?></span>
        </div>

        <div class="tt-exam-hero__cta">
          <a href="#accordion-quiz" class="tt-btn tt-btn--primary"><?php esc_html_e( 'Start Practice', 'tentracker' ); ?></a>
          <?php if ( is_user_logged_in() ) : ?>
            <a href="<?php echo esc_url( home_url( '/my-attempts' ) ); ?>" class="tt-btn tt-btn--outline"><?php esc_html_e( 'View My Progress', 'tentracker' ); ?></a>
          <?php else : ?>
            <a href="<?php echo esc_url( wp_registration_url() ); ?>" class="tt-btn tt-btn--outline"><?php esc_html_e( 'Create free account', 'tentracker' ); ?></a>
          <?php endif; ?>
        </div>
      </div>

      <div class="tt-exam-hero__card">
        <div class="tt-exam-hero__card-title"><?php esc_html_e( 'Exam snapshot', 'tentracker' ); ?></div>
        <div class="tt-exam-hero__card-list">
          <div class="tt-exam-hero__card-row">
            <span><?php esc_html_e( 'Quizzes', 'tentracker' ); ?></span>
            <strong id="tt-exam-quiz-count">—</strong>
          </div>
          <div class="tt-exam-hero__card-row">
            <span><?php esc_html_e( 'Questions', 'tentracker' ); ?></span>
            <strong id="tt-exam-question-count">—</strong>
          </div>
          <div class="tt-exam-hero__card-row">
            <span><?php esc_html_e( 'Difficulty', 'tentracker' ); ?></span>
            <strong id="tt-exam-diff-mix">—</strong>
          </div>
        </div>
        <div class="tt-exam-hero__card-foot">
          <span class="tt-exam-hero__card-note"><?php esc_html_e( 'Data updates automatically from your question bank.', 'tentracker' ); ?></span>
        </div>
      </div>
    </div>
  </div>
</header>

<div class="tt-content">
  <div class="tt-container">
    <main id="main" class="site-main tt-exam-main">

      <?php if ( get_the_content() ) : ?>
        <div class="tt-exam-intro entry-content">
          <?php the_content(); ?>
        </div>
      <?php endif; ?>

      <section class="tt-accordions" aria-label="<?php esc_attr_e( 'Exam sections', 'tentracker' ); ?>">

        <!-- Accordion: Quiz List (open by default) -->
        <div class="tt-accordion" id="accordion-quiz" data-tt-accordion="quiz">
          <button class="tt-accordion__header" type="button" aria-expanded="true">
            <span class="tt-accordion__icon" aria-hidden="true">📋</span>
            <span class="tt-accordion__title"><?php esc_html_e( 'Practice Quizzes', 'tentracker' ); ?></span>
            <span class="tt-accordion__chevron" aria-hidden="true">▾</span>
          </button>
          <div class="tt-accordion__body">
            <div class="tt-quiz-panel">
              <div class="tt-quiz-filters" role="region" aria-label="<?php esc_attr_e( 'Quiz filters', 'tentracker' ); ?>">
                <label class="tt-input">
                  <span class="tt-input__icon" aria-hidden="true">🔎</span>
                  <input type="search" id="tt-quiz-search" placeholder="<?php esc_attr_e( 'Search quizzes…', 'tentracker' ); ?>" autocomplete="off">
                </label>

                <label class="tt-select">
                  <span class="tt-select__icon" aria-hidden="true">⚡</span>
                  <select id="tt-quiz-difficulty" aria-label="<?php esc_attr_e( 'Difficulty', 'tentracker' ); ?>">
                    <option value=""><?php esc_html_e( 'All difficulty', 'tentracker' ); ?></option>
                    <option value="easy"><?php esc_html_e( 'Easy', 'tentracker' ); ?></option>
                    <option value="medium"><?php esc_html_e( 'Medium', 'tentracker' ); ?></option>
                    <option value="hard"><?php esc_html_e( 'Hard', 'tentracker' ); ?></option>
                  </select>
                </label>

                <button class="tt-btn tt-btn--outline tt-btn--sm" type="button" id="tt-quiz-clear">
                  <?php esc_html_e( 'Clear', 'tentracker' ); ?>
                </button>

                <div class="tt-quiz-results-meta">
                  <span id="tt-quiz-results-count">—</span>
                </div>
              </div>

              <div class="tt-quiz-loading" id="tt-quiz-loading" role="status" aria-live="polite">
                <?php esc_html_e( 'Loading quizzes…', 'tentracker' ); ?>
              </div>

              <div class="tt-quiz-empty" id="tt-quiz-empty" role="status" aria-live="polite" style="display:none;">
                <?php esc_html_e( 'No quizzes match your filters.', 'tentracker' ); ?>
              </div>

              <div class="tt-quiz-table-wrap" id="tt-quiz-table-wrap" style="display:none;">
                <table class="tt-quiz-table" aria-label="<?php esc_attr_e( 'Quiz list', 'tentracker' ); ?>">
                  <thead>
                    <tr>
                      <th scope="col">#</th>
                      <th scope="col"><?php esc_html_e( 'Quiz Name', 'tentracker' ); ?></th>
                      <th scope="col"><?php esc_html_e( 'Questions', 'tentracker' ); ?></th>
                      <th scope="col"><?php esc_html_e( 'Difficulty', 'tentracker' ); ?></th>
                      <th scope="col"><?php esc_html_e( 'Action', 'tentracker' ); ?></th>
                    </tr>
                  </thead>
                  <tbody id="tt-quiz-tbody"></tbody>
                </table>
              </div>

              <div class="tt-quiz-cards" id="tt-quiz-cards" style="display:none;"></div>
            </div>
          </div>
        </div>

        <!-- Accordion: Current Affairs -->
        <div class="tt-accordion" id="accordion-ca" data-tt-accordion="current-affairs">
          <button class="tt-accordion__header" type="button" aria-expanded="false">
            <span class="tt-accordion__icon" aria-hidden="true">📰</span>
            <span class="tt-accordion__title"><?php esc_html_e( 'Current Affairs', 'tentracker' ); ?></span>
            <span class="tt-accordion__chevron" aria-hidden="true">▾</span>
          </button>
          <div class="tt-accordion__body">
            <?php if ( $ca_html ) : ?>
              <div class="tt-exam-rich entry-content">
                <?php echo apply_filters( 'the_content', $ca_html ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
              </div>
            <?php else : ?>
              <div class="tt-exam-empty">
                <?php esc_html_e( 'Add current affairs content from the Exam editor.', 'tentracker' ); ?>
              </div>
            <?php endif; ?>
          </div>
        </div>

        <!-- Accordion: About -->
        <div class="tt-accordion" id="accordion-about" data-tt-accordion="about">
          <button class="tt-accordion__header" type="button" aria-expanded="false">
            <span class="tt-accordion__icon" aria-hidden="true">ℹ️</span>
            <span class="tt-accordion__title"><?php esc_html_e( 'About this Exam', 'tentracker' ); ?></span>
            <span class="tt-accordion__chevron" aria-hidden="true">▾</span>
          </button>
          <div class="tt-accordion__body">
            <?php if ( $about_html ) : ?>
              <div class="tt-exam-rich entry-content">
                <?php echo apply_filters( 'the_content', $about_html ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
              </div>
            <?php else : ?>
              <div class="tt-exam-empty">
                <?php esc_html_e( 'Add “About” content from the Exam editor.', 'tentracker' ); ?>
              </div>
            <?php endif; ?>
          </div>
        </div>

        <!-- Accordion: Syllabus (optional) -->
        <?php if ( $syllabus_html ) : ?>
        <div class="tt-accordion" id="accordion-syllabus" data-tt-accordion="syllabus">
          <button class="tt-accordion__header" type="button" aria-expanded="false">
            <span class="tt-accordion__icon" aria-hidden="true">🧾</span>
            <span class="tt-accordion__title"><?php esc_html_e( 'Syllabus', 'tentracker' ); ?></span>
            <span class="tt-accordion__chevron" aria-hidden="true">▾</span>
          </button>
          <div class="tt-accordion__body">
            <div class="tt-exam-rich entry-content">
              <?php echo apply_filters( 'the_content', $syllabus_html ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
            </div>
          </div>
        </div>
        <?php endif; ?>

        <!-- Custom Accordions -->
        <?php foreach ( $extra_items as $idx => $item ) :
            if ( ! is_array( $item ) ) continue;
            $t = sanitize_text_field( $item['title'] ?? '' );
            $c = $item['content'] ?? '';
            if ( '' === trim( $t ) && '' === trim( (string) $c ) ) continue;
            $acc_id = 'accordion-extra-' . (int) $idx;
        ?>
          <div class="tt-accordion" id="<?php echo esc_attr( $acc_id ); ?>" data-tt-accordion="extra-<?php echo (int) $idx; ?>">
            <button class="tt-accordion__header" type="button" aria-expanded="false">
              <span class="tt-accordion__icon" aria-hidden="true">📌</span>
              <span class="tt-accordion__title"><?php echo esc_html( $t ?: __( 'More', 'tentracker' ) ); ?></span>
              <span class="tt-accordion__chevron" aria-hidden="true">▾</span>
            </button>
            <div class="tt-accordion__body">
              <div class="tt-exam-rich entry-content">
                <?php echo apply_filters( 'the_content', (string) $c ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
              </div>
            </div>
          </div>
        <?php endforeach; ?>

      </section>

    </main>
  </div>
</div>

<?php get_footer();
