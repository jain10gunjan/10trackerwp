/* global ttExam */
(function () {
  'use strict';

  var cfg = window.ttExam || {};
  var restBase = (cfg.restUrl || '').replace(/\/+$/, '') + '/';
  var category = (cfg.category || '').toString();
  var nonce = (cfg.nonce || '').toString();
  var examSlug = (cfg.examSlug || '').toString() || 'exam';

  var els = {
    search: document.getElementById('tt-quiz-search'),
    difficulty: document.getElementById('tt-quiz-difficulty'),
    clear: document.getElementById('tt-quiz-clear'),
    loading: document.getElementById('tt-quiz-loading'),
    empty: document.getElementById('tt-quiz-empty'),
    wrap: document.getElementById('tt-quiz-table-wrap'),
    tbody: document.getElementById('tt-quiz-tbody'),
    cards: document.getElementById('tt-quiz-cards'),
    resultsCount: document.getElementById('tt-quiz-results-count'),
    heroQuizCount: document.getElementById('tt-exam-quiz-count'),
    heroQuestionCount: document.getElementById('tt-exam-question-count'),
    heroDiffMix: document.getElementById('tt-exam-diff-mix')
  };

  function escHtml(str) {
    var d = document.createElement('div');
    d.textContent = str == null ? '' : String(str);
    return d.innerHTML;
  }

  function normDifficulty(val) {
    var v = (val || '').toString().trim().toLowerCase();
    if (!v) return '';
    if (v === 'e') return 'easy';
    if (v === 'm') return 'medium';
    if (v === 'h') return 'hard';
    if (v.indexOf('easy') === 0) return 'easy';
    if (v.indexOf('med') === 0) return 'medium';
    if (v.indexOf('hard') === 0) return 'hard';
    return v;
  }

  function debounce(fn, ms) {
    var t = null;
    return function () {
      var args = arguments;
      clearTimeout(t);
      t = setTimeout(function () { fn.apply(null, args); }, ms);
    };
  }

  function isMobile() {
    return window.matchMedia && window.matchMedia('(max-width: 720px)').matches;
  }

  var state = {
    all: [],
    filtered: [],
    q: '',
    diff: ''
  };

  function setLoading(isLoading) {
    if (!els.loading) return;
    els.loading.style.display = isLoading ? '' : 'none';
  }

  function setEmpty(isEmpty) {
    if (!els.empty) return;
    els.empty.style.display = isEmpty ? '' : 'none';
  }

  function setVisibleList(hasData) {
    if (!els.wrap || !els.cards) return;
    var mobile = isMobile();
    els.wrap.style.display = (!mobile && hasData) ? '' : 'none';
    els.cards.style.display = (mobile && hasData) ? '' : 'none';
  }

  function updateMeta() {
    var n = state.filtered.length;
    if (els.resultsCount) {
      els.resultsCount.textContent = n === 1 ? '1 quiz' : (n + ' quizzes');
    }
  }

  function computeHeroStats(list) {
    var quizCount = list.length;
    var qTotal = 0;
    var diffCounts = { easy: 0, medium: 0, hard: 0 };
    list.forEach(function (q) {
      qTotal += Number(q.questions || q.question_count || 0) || 0;
      var d = normDifficulty(q.difficulty);
      if (diffCounts[d] != null) diffCounts[d]++;
    });

    if (els.heroQuizCount) els.heroQuizCount.textContent = quizCount ? String(quizCount) : '0';
    if (els.heroQuestionCount) els.heroQuestionCount.textContent = qTotal ? String(qTotal) : '0';

    if (els.heroDiffMix) {
      var parts = [];
      if (diffCounts.easy) parts.push('Easy ' + diffCounts.easy);
      if (diffCounts.medium) parts.push('Medium ' + diffCounts.medium);
      if (diffCounts.hard) parts.push('Hard ' + diffCounts.hard);
      els.heroDiffMix.textContent = parts.length ? parts.join(' · ') : '—';
    }
  }

  function render() {
    var list = state.filtered;
    updateMeta();
    setEmpty(list.length === 0);
    setVisibleList(list.length > 0);

    // Desktop table
    if (els.tbody) {
      var html = '';
      for (var i = 0; i < list.length; i++) {
        var item = list[i];
        var name = item.title || item.quiz_name || item.name || ('Quiz ' + (i + 1));
        var qs = item.questions != null ? item.questions : (item.question_count != null ? item.question_count : '');
        var diff = normDifficulty(item.difficulty);
        var diffLabel = diff ? diff.charAt(0).toUpperCase() + diff.slice(1) : '—';
        var startUrl = item.url || item.start_url || item.link || '';
        var action = startUrl
          ? '<a class="tt-quiz-action" href="' + escHtml(startUrl) + '">Start →</a>'
          : '<span class="tt-quiz-action tt-quiz-action--disabled">Start →</span>';

        html += '<tr>';
        html += '<td class="tt-quiz-col-num">' + (i + 1) + '</td>';
        html += '<td class="tt-quiz-col-name"><span class="tt-quiz-name">' + escHtml(name) + '</span></td>';
        html += '<td class="tt-quiz-col-qs">' + escHtml(qs) + '</td>';
        html += '<td class="tt-quiz-col-diff"><span class="tt-diff tt-diff--' + escHtml(diff || 'na') + '">' + escHtml(diffLabel) + '</span></td>';
        html += '<td class="tt-quiz-col-action">' + action + '</td>';
        html += '</tr>';
      }
      els.tbody.innerHTML = html;
    }

    // Mobile cards
    if (els.cards) {
      var chtml = '';
      for (var j = 0; j < list.length; j++) {
        var it = list[j];
        var nm = it.title || it.quiz_name || it.name || ('Quiz ' + (j + 1));
        var qn = it.questions != null ? it.questions : (it.question_count != null ? it.question_count : '');
        var df = normDifficulty(it.difficulty);
        var dfLabel = df ? df.charAt(0).toUpperCase() + df.slice(1) : '—';
        var url = it.url || it.start_url || it.link || '';
        var btn = url
          ? '<a class="tt-btn tt-btn--primary tt-btn--sm" href="' + escHtml(url) + '">Start →</a>'
          : '<span class="tt-btn tt-btn--primary tt-btn--sm tt-btn--disabled">Start →</span>';

        chtml += '<div class="tt-quiz-card">';
        chtml += '  <div class="tt-quiz-card__top">';
        chtml += '    <div class="tt-quiz-card__title">' + escHtml(nm) + '</div>';
        chtml += '    <span class="tt-diff tt-diff--' + escHtml(df || 'na') + '">' + escHtml(dfLabel) + '</span>';
        chtml += '  </div>';
        chtml += '  <div class="tt-quiz-card__meta">';
        chtml += '    <span>' + escHtml(qn) + ' Qs</span>';
        chtml += '  </div>';
        chtml += '  <div class="tt-quiz-card__actions">' + btn + '</div>';
        chtml += '</div>';
      }
      els.cards.innerHTML = chtml;
    }
  }

  function applyFilters() {
    var q = (state.q || '').trim().toLowerCase();
    var diff = (state.diff || '').trim().toLowerCase();

    state.filtered = state.all.filter(function (item) {
      var name = (item.title || item.quiz_name || item.name || '').toString().toLowerCase();
      var matchesQ = !q || name.indexOf(q) !== -1;
      var d = normDifficulty(item.difficulty);
      var matchesD = !diff || d === diff;
      return matchesQ && matchesD;
    });
    render();
  }

  var debouncedApply = debounce(applyFilters, 300);

  function bindFilters() {
    if (els.search) {
      els.search.addEventListener('input', function () {
        state.q = els.search.value || '';
        debouncedApply();
      });
    }
    if (els.difficulty) {
      els.difficulty.addEventListener('change', function () {
        state.diff = els.difficulty.value || '';
        applyFilters();
      });
    }
    if (els.clear) {
      els.clear.addEventListener('click', function () {
        if (els.search) els.search.value = '';
        if (els.difficulty) els.difficulty.value = '';
        state.q = '';
        state.diff = '';
        applyFilters();
      });
    }
    window.addEventListener('resize', debounce(function () {
      // toggle between table/cards without rerendering data
      setVisibleList(state.filtered.length > 0);
    }, 150));
  }

  function normalizeApiResponse(data) {
    // Accept: array, { items: [] }, { data: [] }, { questions: [] }, etc.
    if (Array.isArray(data)) return data;
    if (data && Array.isArray(data.items)) return data.items;
    if (data && Array.isArray(data.data)) return data.data;
    if (data && Array.isArray(data.quizzes)) return data.quizzes;
    if (data && Array.isArray(data.questions)) return data.questions;
    return [];
  }

  function loadQuizzes() {
    if (!restBase || !category) {
      setLoading(false);
      setEmpty(true);
      if (els.empty) els.empty.textContent = 'Quiz category is not configured for this exam.';
      return;
    }

    var url = restBase + 'questions?category=' + encodeURIComponent(category);
    setLoading(true);
    setEmpty(false);

    fetch(url, {
      method: 'GET',
      credentials: 'same-origin',
      headers: {
        'Accept': 'application/json',
        'X-WP-Nonce': nonce
      }
    })
      .then(function (r) {
        if (!r.ok) throw new Error('HTTP ' + r.status);
        return r.json();
      })
      .then(function (json) {
        var items = normalizeApiResponse(json);

        // Ensure shape: title, questions/question_count, difficulty, url
        state.all = items.map(function (it, idx) {
          var obj = it || {};
          return {
            id: obj.id || obj.quiz_id || idx,
            title: obj.title || obj.quiz_name || obj.name || obj.quizTitle || '',
            questions: obj.questions != null ? obj.questions : (obj.question_count != null ? obj.question_count : obj.total_questions),
            difficulty: obj.difficulty || obj.level || obj.diff || '',
            url: obj.url || obj.start_url || obj.link || obj.permalink || ''
          };
        });

        state.filtered = state.all.slice();
        setLoading(false);
        computeHeroStats(state.all);
        render();
      })
      .catch(function () {
        setLoading(false);
        setEmpty(true);
        if (els.empty) els.empty.textContent = 'Unable to load quizzes right now. Please try again later.';
      });
  }

  // Accordion
  function initAccordions() {
    var accordions = Array.prototype.slice.call(document.querySelectorAll('.tt-accordion'));
    if (!accordions.length) return;

    var storageKey = 'ttExamAccordion:' + examSlug;

    function setExpanded(acc, expanded, skipPersist) {
      var btn = acc.querySelector('.tt-accordion__header');
      var body = acc.querySelector('.tt-accordion__body');
      if (!btn || !body) return;

      btn.setAttribute('aria-expanded', expanded ? 'true' : 'false');
      acc.classList.toggle('is-open', !!expanded);

      if (expanded) {
        body.style.maxHeight = body.scrollHeight + 'px';
      } else {
        body.style.maxHeight = '0px';
      }

      if (!skipPersist) {
        try {
          var openId = expanded ? (acc.getAttribute('id') || '') : '';
          localStorage.setItem(storageKey, openId);
        } catch (e) {}
      }
    }

    function collapseOthers(current) {
      accordions.forEach(function (acc) {
        if (acc === current) return;
        setExpanded(acc, false, true);
      });
    }

    // initial sizing (ensure open accordion has proper height)
    function recalcOpen() {
      accordions.forEach(function (acc) {
        if (acc.classList.contains('is-open')) {
          var body = acc.querySelector('.tt-accordion__body');
          if (body) body.style.maxHeight = body.scrollHeight + 'px';
        }
      });
    }

    // Restore persisted accordion if available
    var persisted = '';
    try { persisted = localStorage.getItem(storageKey) || ''; } catch (e) {}
    if (persisted) {
      accordions.forEach(function (acc) {
        setExpanded(acc, (acc.getAttribute('id') === persisted), true);
      });
    } else {
      // default: first accordion open, others closed
      accordions.forEach(function (acc, idx) {
        var btn = acc.querySelector('.tt-accordion__header');
        var expanded = btn && btn.getAttribute('aria-expanded') === 'true';
        if (idx === 0) setExpanded(acc, true, true);
        else setExpanded(acc, expanded, true);
      });
    }

    accordions.forEach(function (acc) {
      var btn = acc.querySelector('.tt-accordion__header');
      if (!btn) return;

      btn.addEventListener('click', function () {
        var isOpen = btn.getAttribute('aria-expanded') === 'true';
        var next = !isOpen;
        if (next) collapseOthers(acc);
        setExpanded(acc, next, false);

        // when opening quiz accordion, recalc after load
        if (next) setTimeout(recalcOpen, 60);
      });

      btn.addEventListener('keydown', function (e) {
        var key = e.key || e.code;
        if (key === 'Enter' || key === ' ' || key === 'Spacebar') {
          e.preventDefault();
          btn.click();
        }
      });
    });

    window.addEventListener('resize', debounce(recalcOpen, 150));
    // Recalc after fonts/images settle
    setTimeout(recalcOpen, 250);
  }

  document.addEventListener('DOMContentLoaded', function () {
    initAccordions();
    bindFilters();
    loadQuizzes();
  });
})();

